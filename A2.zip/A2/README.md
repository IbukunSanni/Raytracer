# A2 read me

## Compilation
The program is located in the downloads folder. As a result, you have to **cd**
into **~/Downloads/cs488/A2** the run the following to open the program:

    $ premake4 gmake
    $ make
    $ ./A2

## Manual
- Scaling is limited
- Near and Far planes cannot cross each other
- FOVY changes are very subtle
