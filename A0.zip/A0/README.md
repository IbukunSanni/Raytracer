# A0 read me

## Compilation
The program is located in the downloads folder. As a result, you have to **cd**
into **~/Downloads/cs488/A0** the run the following to open the program:

    $ premake4 gmake
    $ make
    $ ./A0

## Manual
The rotation slider ranges from 0 to 2 * PI because it is in radians
scale up multiplies by 1.5
scale down divides by 1.5
