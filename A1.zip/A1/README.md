# A1 read me

## Compilation
The program is located in the downloads folder. As a result, you have to **cd**
into **~/Downloads/cs488/A1** the run the following to open the program:

    $ premake4 gmake
    $ make
    $ ./A0

## Manual
- The avatar can walk outside on the grid
- rotation and persistence are not implemented
- GUI for color change for Block, Avatar and floor are present. However,
they are not implemented
